<?php

    require_once 'phpqrcode.php'; 

    $code = htmlspecialchars($_GET['code']);
    QRCode::png("https://" . $_SERVER['HTTP_HOST'] . "/track.php?code=" . $code);

?>