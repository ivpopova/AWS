window.addEventListener('load', function () {
  const links = document.querySelectorAll("a:not(.extlink)");

  for (var i = 0, len = links.length; i < len; i++) {
    links[i].addEventListener("click", clickHandler);
  }
});

function clickHandler(e) {
  e.preventDefault();
  const href = this.getAttribute("href");
  const offsetTop = document.querySelector(href).offsetTop;
  const headerHeight = document.querySelector("header").offsetTop;

  scroll({
    top: offsetTop + headerHeight + 1,
    behavior: "smooth"
  });
}

document.addEventListener('scroll', function(e) {
  const currentPosition = document.documentElement.scrollTop;
  const sectionsInDocument = document.querySelectorAll("section");
  var idOfLastSection = (sectionsInDocument[sectionsInDocument.length-1]).getAttribute("id");
  const split = idOfLastSection.split("-");
  idOfLastSection = split[1];

  var selectedSection = idOfLastSection;

  for (var i = 1; i < idOfLastSection; i++) {
    const selectorFirst = "#sect-"+i;
    const selectorSecond = "#sect-"+(i+1);
    const firstSectionOffset = document.querySelector(selectorFirst).offsetTop;
    const secondSectionOffset = document.querySelector(selectorSecond).offsetTop;
    if (currentPosition >= firstSectionOffset && currentPosition <= secondSectionOffset) {
      selectedSection = i;
      break;
    }
  }

  const menuItems = document.querySelectorAll("aside a");

  for (var i = 0, len = menuItems.length; i < len; i++) {
    if (menuItems[i].classList.contains("active")) {
      menuItems[i].classList.remove("active");
    }
  }

  if ((window.innerHeight + currentPosition) >= document.body.offsetHeight) {
    menuItems[idOfLastSection-1].classList.add("active");
  }
  else {
    menuItems[selectedSection-1].classList.add("active");
  }
}, {passive: true});
